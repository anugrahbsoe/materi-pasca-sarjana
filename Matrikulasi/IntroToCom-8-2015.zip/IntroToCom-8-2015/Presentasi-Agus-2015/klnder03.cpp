#include<stdio.h>
//hanya untuk tahun 1901 sampai dengan tahun 2099
void main()
{ int NoBul[15] ={99,1,32,25,21,16,12,7,3,34,29,25,20,35,31};
  int NoTah[101]={ 29,14,34,19, 3,23, 8,28,12,32,17,
							  2,21, 6,26,11,30,15,35,20, 4,
							 24, 9,29,13,33,18, 3,22, 7,27,
							 12,31,16, 1,21, 5,25,10,30,14,
							 34,19, 4,23, 8,28,13,32,17, 2,
							 22, 6,26,11,31,15,35,20, 5,24,
							  9,29,14,33,18, 3,23, 7,27,12,
							 32,16, 1,21, 6,25,10,30,15,34,
							 19, 4,24, 8,28,13,33,17, 2,22,
							  7,26,11,31,16,35,20, 5,25,29 };
  int NomorHari[36];
  int NomorLegi[36];
  char NamaHari[8][10] = { "xxx", "Minggu", "Senin", "Selasa",
											 "Rabu", "Kamis", "Jum'at", "Sabtu" };
  char NamaLegi[6][10] = { "xxx", "Pahing", "Pon", "Wage","Kliwon", "Legi" };
  char NamaBulan[13][10] ={"xxx", "Januari",  "Februari", "Maret",    "April",
											 "Mei",      "Juni",     "Juli",     "Agustus",
											 "September","Oktober",  "November", "Desember" };
  int dd, mm, yy1, yy2;
  int Tgl0, Tgldd, Noyy1, Tahunyy2, Geseryy, Nodd, NoHari, NoLegi;
  int i,j,n, yyyy;
  n=1;
  for(i=1;i<=5;i++)
	  {for(j=1;j<=7;j++)
			 { NomorHari[n]=j; n++; }
	  }
  n=1;
  for(i=1;i<=7;i++)
	  {for(j=1;j<=5;j++)
			 { NomorLegi[n]=j; n++; }
	  }
  printf("Tanggal dd : " ); scanf("%i", &dd);
  printf("Bulan   mm : " ); scanf("%i", &mm);

  printf("Tahun yyyy : " ); scanf("%i", &yyyy);
  yy1 = yyyy / 100;
  yy2 = yyyy % 100;
  //data belum divalidasi
  
	Tgl0 = NoBul[mm];
	if(yy2%4==0)
	  { if(mm==1)Tgl0=35;
		 else { if(mm==2) Tgl0=31; }
	  }
	Tgldd=(Tgl0+dd) % 35;
	if(yy1==20) Noyy1=28; else Noyy1 = 8;
	Tahunyy2 = NoTah[yy2];
	if(Tahunyy2 < Noyy1 )
		{Geseryy = Tahunyy2 + 35 - Noyy1; }
	else
		{ Geseryy = Tahunyy2 - Noyy1; }
	Nodd = Tgldd - Geseryy;
	if(Nodd < 1 ) Nodd=Nodd+35;
	NoHari = NomorHari[Nodd];
	NoLegi = NomorLegi[Nodd];
	printf("\n%s %s",NamaHari[NoHari], NamaLegi[NoLegi]);
	printf("\n\nHari Keberuntungan Anda : " );
	printf("%s %s",NamaHari[NoHari%5 + 2], NamaLegi[NoLegi%3+2] );
	printf("\nPada Setiap Bulan       : %s  dan  %s ",
	          NamaBulan[mm%6+2], NamaBulan[mm%6+4]);
}
